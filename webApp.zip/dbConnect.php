<?php
    $dbServerName = $_SERVER['RDS_HOSTNAME'];
    $dbUsername =  $_SERVER['RDS_USERNAME'];
    $dbPassword = $_SERVER['RDS_PASSWORD'];
    $dbName =  $_SERVER['RDS_DB_NAME'];
    $conn = mysqli_connect($dbServerName, $dbUsername,$dbPassword, $dbName);        // Connect Database
    if(!$conn)
    {
      echo "Connection erorr!";
    }
    else {
      session_start();
    }
